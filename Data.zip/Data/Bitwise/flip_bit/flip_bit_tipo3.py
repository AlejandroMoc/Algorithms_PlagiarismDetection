def invertir_bit(num, posicion):
    return num ^ (1 << posicion)  # Invertir el bit en la posición especificada