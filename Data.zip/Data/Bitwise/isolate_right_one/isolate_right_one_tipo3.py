def extract_rightmost_one(num):
    return num & -num