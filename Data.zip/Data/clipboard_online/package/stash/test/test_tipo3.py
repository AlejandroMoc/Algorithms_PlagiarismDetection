def print_message(message):
    print(message)

print_message("If it's visible, then it's good to go!")