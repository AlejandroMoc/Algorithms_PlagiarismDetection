print("If it's visible, then it's good to go!")
