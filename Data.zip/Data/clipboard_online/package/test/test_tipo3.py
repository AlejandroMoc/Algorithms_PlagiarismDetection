from scrap.grab import guardar, mostrar, recortar

guardar("fghd", "text.txt")
mostrar("fghd")
recortar("fghd")