from scrap.grab import write, show, clip

write("fghd", "text.txt")
show("fghd")
clip("fghd")
