from scrap.grab import compose, display, trim

compose("fghd", "text.txt")
display("fghd")
trim("fghd")